package tests;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import utils.TestConfig;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CepTest {

    // Configura o URI base antes de executar os testes
    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = TestConfig.BASE_URI;
    }

    @ParameterizedTest
    @MethodSource("utils.TestConfig#VALID_CEPS")
    public void testValidCep(String cep) {
        testCep(cep, false);
    }

    @ParameterizedTest
    @MethodSource("utils.TestConfig#INVALID_CEPS")
    public void testInvalidCep(String cep) {
        testCep(cep, true);
    }

    private void testCep(String cep, boolean invalid) {
        // Define o endpoint e o tipo de conteúdo da requisição
        given()
            .contentType(ContentType.JSON)
        // Faz uma requisição GET para o endpoint com o CEP como parâmetro
        .when()
            .get("/" + cep + "/json")
        // Verifica se a resposta tem o status code 200 (OK) e se os campos da resposta estão corretos
        .then()
            .statusCode(200)
            .body(invalid ? "erro" : "cep", equalTo(invalid ? true : cep));
    }
}